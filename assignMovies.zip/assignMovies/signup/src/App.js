import logo from './logo.svg';
import './App.css';
import React from 'react';
import Signup from './components/Signup';
import NavBar from './components/NavBar';
import Movies from './components/Movies';



function App() {
  return (
    <div className="App">
      {/* <Signup/> */}
      <NavBar/>
      <Movies/>
    </div>
  );
}

export default App;
