import React, { Component } from 'react';
import MoviesItem from './MoviesItem';



export class Movies extends Component {
        




    constructor(){
      super();
      this.state={
          movies:[],
          loading:false,
          
      }
    }

   componentDidMount(){


    fetch('https://imdb-top-100-movies.p.rapidapi.com/', {
      method: 'GET',
      
      headers: {
        'X-RapidAPI-Key': '47e4453c2bmshef08d3a41aa995ap1d11e0jsn1656b8693f08',
        'X-RapidAPI-Host': 'imdb-top-100-movies.p.rapidapi.com'
      }
    })
    
    .then(response=>response.json())
    .then(data=>{
        const movies=data;
        this.setState({
            movies:movies,
             loading:false
          })
        
        console.log(movies)
    }) 
    .catch(error=> {
        console.error(error);
    });
    
    
        
    }


   render() {
    return (
      <div className='container my-3'>
        <h1 className='text-center'>Movies-IMDB rating</h1>
       
       
        <div className='row'>
        { this.state.movies.map((item)=>{
          return <div className="col-md-4" key={item.id}>
          <MoviesItem  title={item.title} description={item.description} image={item.image} rank={item.rank}/>
          </div>
          })}
         
          </div>
          
      </div>
    )
  }
}

export default Movies