import React, { Component } from 'react'

export class MoviesItem extends Component {

  render() {
   let {title,description,image,rank}=this.props;
    return (
    <div className="my-3">
        <div className="card" style={{width: "18rem"}}>
        <img src={image} className="card-img-top" alt="..."/>
            <div className="card-body">
                <h4>{rank}</h4>
            <h5 className="card-title">{title}
            </h5>
            <p className="card-text">{description}</p>
           
            </div>
        </div>
    </div>
    )
  }
}

export default MoviesItem